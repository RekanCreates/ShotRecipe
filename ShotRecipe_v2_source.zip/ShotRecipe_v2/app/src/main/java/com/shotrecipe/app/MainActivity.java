package com.shotrecipe.app;

import android.app.Activity;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout root, library;
    Spinner deviceSpinner;
    EditText searchBox;
    TextView countLabel;
    String selectedCategory = "All";
    boolean favoritesOnly = false;
    boolean showingRecipe = false;
    SharedPreferences prefs;
    ArrayList<Device> devices = new ArrayList<>();
    ArrayList<Recipe> recipes = new ArrayList<>();
    final int BG = Color.rgb(10,12,16);
    final int CARD = Color.rgb(20,24,32);
    final int TEXT = Color.rgb(245,247,250);
    final int MUTED = Color.rgb(164,173,188);
    final int ACCENT = Color.rgb(246,184,104);

    int dp(float v){ return (int)(v*getResources().getDisplayMetrics().density+0.5f); }
    TextView tv(String text,float size,int color,boolean bold){
        TextView t=new TextView(this); t.setText(text); t.setTextSize(size); t.setTextColor(color); t.setGravity(Gravity.CENTER_VERTICAL);
        if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD); return t;
    }
    GradientDrawable bg(int color,float radius){ GradientDrawable g=new GradientDrawable(); g.setColor(color); g.setCornerRadius(dp(radius)); return g; }
    Button button(String text){ Button b=new Button(this); b.setText(text); b.setTextColor(Color.WHITE); b.setTextSize(12); b.setAllCaps(false); b.setBackground(bg(Color.rgb(35,41,52),18)); b.setPadding(dp(12),0,dp(12),0); return b; }

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        prefs=getSharedPreferences("shotrecipe",MODE_PRIVATE);
        buildData();
        home();
    }

    @Override public void onBackPressed(){
        if(showingRecipe){
            home();
        } else {
            super.onBackPressed();
        }
    }

    void buildData(){
        devices.add(new Device("vivo X300", "Main 23mm class • Tele 3x / 50mm class • UW 119.4° • f/1.57 / f/2.67 / f/2.0", 23, 50, 15, 1.57, 2.67, 2.0));
        devices.add(new Device("vivo X300 Pro", "Main 24mm class • Tele 3.5x / 85mm class • UW 119° • f/1.57 / f/2.67 / f/2.0", 24, 85, 15, 1.57, 2.67, 2.0));
        devices.add(new Device("Generic Android", "Use the closest optical lens available; recipes are starting points", 24, 70, 14, 1.8, 2.8, 2.2));

        String[][] data = new String[][]{
            {"Portrait","Window Portrait","Soft window light • clean skin • shallow-looking depth","Window light is best from the side. Turn the face 20–30° toward the window and keep the background distant."},
            {"Portrait","Backlit Portrait","Bright rim light • lifted skin • separation","Put the light behind the subject. Protect highlights and slightly underexpose rather than chasing a perfect face meter."},
            {"Portrait","Street Portrait","Environmental portrait • natural perspective","Use the main lens or 50mm-class tele. Step back until the face looks natural, then recompose."},
            {"Portrait","Editorial Portrait","Controlled pose • crisp detail • fashion feel","Keep the subject still, use a clean background, and use the tele camera when light allows."},
            {"Portrait","Low-Key Portrait","Deep shadows • focused highlights • dramatic mood","Place one soft light to one side of the face and let the opposite side fall away. Meter the lit skin."},
            {"Portrait","Silhouette Portrait","Graphic outline • glowing background","Expose for the background, lock focus on the subject, and keep the body shape readable."},
            {"Golden Hour","Golden Glow","Warm sunset wrap • soft contrast","Shoot 15–30 minutes before sunset with the sun near the frame edge. Keep white balance slightly warm."},
            {"Golden Hour","Sunset Rim Light","Bright edge light • dark hair/shoulders","Backlight the subject and lower exposure until the bright sky retains color."},
            {"Golden Hour","Warm Side Light","Directional sunlight • textured skin","Use side light for shape. Avoid midday overhead sun; late light gives a gentler gradient."},
            {"Golden Hour","Lens Flare Portrait","Intentional flare • dreamy glow","Clean the lens, aim slightly toward the sun, and let a small flare enter while keeping the face readable."},
            {"Golden Hour","Beach Golden Hour","Warm horizon • reflective highlights","Watch the water and sand for hot highlights. Lower EV a little and use the tele for compression."},
            {"Golden Hour","Urban Golden Hour","Warm buildings • long shadows","Use a street wall or glass facade as a reflector and shoot along the direction of the sun."},
            {"Blue Hour","Blue Hour Street","Blue sky • warm windows • balanced city","Shoot 10–25 minutes after sunset. The sky should still be blue while artificial lights are on."},
            {"Blue Hour","Twilight Portrait","Cool background • warm face","Put your subject near a shop/window light and keep the sky in the background."},
            {"Blue Hour","City Blue Hour","Evening cityscape • glowing detail","Brace the phone. Use the main lens, moderate shutter, and low ISO."},
            {"Blue Hour","Blue Hour Bridge","Leading lines • cool atmosphere","Center or offset the bridge lines. A solid support helps if you go below 1/30s."},
            {"Blue Hour","Blue Hour Rooftop","Wide sky • city glow","Use the main lens and wait until the brightest signs begin to glow without clipping."},
            {"Blue Hour","Blue Hour Rain","Wet pavement • cyan mood","Find wet reflections. Expose for signs rather than the dark street."},
            {"Night","Neon Alley","Colorful signs • dark surroundings","Get close to one strong neon source. Expose for the face or brightest object, not the black areas."},
            {"Night","Night Market","Mixed light • candid details","Use a faster shutter for moving people and accept some ISO noise to preserve moments."},
            {"Night","Night Portrait","Clean face • ambient city glow","Prefer the tele only when the light is strong enough. Otherwise use the main lens for more light."},
            {"Night","Wet Street Night","Reflections • saturated color","Shoot toward reflective surfaces after rain and protect bright sign highlights."},
            {"Night","Long Exposure Cars","Headlight trails • static buildings","Use a tripod/solid support. Keep ISO low and shutter between 1–4 seconds."},
            {"Night","Dark Café","Warm practical light • intimate shadows","Place the subject close to a lamp or window and keep the rest of the room dark."},
            {"Street","Candid Walk","Unposed moment • documentary framing","Stay close enough for 23–24mm to feel immersive. Keep the shutter around 1/500s."},
            {"Street","Crosswalk Moment","Geometry • moving subject","Pre-focus near the crossing and wait for the subject to enter your frame."},
            {"Street","Pavement Detail","Texture • low angle • graphic scene","Drop the phone closer to ground level. Use side light to reveal texture."},
            {"Street","Urban Geometry","Shapes • clean lines • repetition","Use the wide/main lens and carefully align edges. Keep perspective intentional."},
            {"Street","Street Vendor","Human story • warm practical light","Meter the face and keep the surrounding environment in frame to tell the story."},
            {"Street","Motion Street","Frozen subject • moving background","Use 1/500s or faster and track the subject with continuous AF."},
            {"Cinematic","Film Still","Quiet composition • controlled contrast","Use a restrained exposure, slightly warm WB, and a subject separated from the background."},
            {"Cinematic","Teal Night","Cool shadows • warm highlights","Let practical lights stay warm while the ambient scene stays cool."},
            {"Cinematic","Warm Shadow","Directional light • rich blacks","Use one dominant light source and avoid filling every shadow."},
            {"Cinematic","Moody Alley","Layered depth • dark edges","Frame foreground, subject, and background into three visual layers."},
            {"Cinematic","Rainy Cinema","Wet streets • reflections • drama","Shoot after rain. Keep reflections in the lower third and let highlights lead the eye."},
            {"Cinematic","Soft Drama","Gentle highlights • subdued saturation","Use open shade or window light and avoid hard midday light."},
            {"Rain","Rainy Window","Raindrops • soft background","Focus close on drops or farther into the scene; choose one layer deliberately."},
            {"Rain","Umbrella Street","Colorful umbrella • wet pavement","Use the umbrella as a bold color anchor and keep the rest slightly darker."},
            {"Rain","Wet Reflections","Mirror-like ground • light trails","Get low and shoot parallel to the wet surface for stronger reflections."},
            {"Rain","Monsoon Portrait","Soft overcast light • natural skin","Cloud cover is your giant softbox. Use moderate shutter and a neutral WB."},
            {"Rain","Raindrop Closeup","Macro-like detail • highlights","Use the tele/macro-capable lens if available and keep the background simple."},
            {"Rain","Rainy Neon","Neon color • heavy atmosphere","Place a neon source behind or beside the subject and expose for the brightest color."},
            {"Travel","Old Street Travel","Storytelling frame • layered street life","Look for a foreground object, subject, and background. Shoot at eye level or slightly lower."},
            {"Travel","Temple Detail","Texture • architecture • calm light","Use the tele for details and keep shutter high enough for handholding."},
            {"Travel","Mountain View","Layered landscape • atmospheric depth","Use the main lens for context and tele for compressed mountain layers."},
            {"Travel","Train Window","Motion • reflections • place memory","Shoot toward the window edge to include reflections without letting them dominate."},
            {"Travel","Seaside Walk","Open sky • leading shoreline","Keep the horizon straight. Use the main lens or ultrawide if the landscape benefits."},
            {"Travel","Rooftop Travel","City panorama • subject in context","Place the person away from center when possible and leave room in the direction they face."},
            {"Architecture","Leading Lines","Strong diagonals • depth","Stand centered or intentionally offset. Keep verticals as straight as possible."},
            {"Architecture","Minimal Facade","Simple planes • clean color","Remove distractions. Wait for one person, shadow, or object to add scale."},
            {"Architecture","Symmetry Hall","Centered geometry • repetition","Use a level horizon and center the vanishing point."},
            {"Architecture","Staircase Geometry","Pattern • rhythm • graphic shadow","Shoot from an angle that turns the stairs into repeating shapes."},
            {"Architecture","Glass Reflection","Double image • layered city","Move until reflection and scene overlap instead of sitting as separate halves."},
            {"Architecture","Brutalist Form","Hard texture • dramatic mass","Shoot in directional light to reveal concrete texture and form."},
            {"Food","Window Food","Soft side light • appetizing detail","Place food beside a window and turn the plate until highlights are controlled."},
            {"Food","Restaurant Table","Atmosphere • warm ambience","Use the main lens at a slight angle. Avoid extreme overhead mixed lighting."},
            {"Food","Coffee Detail","Texture • crema • steam","Focus on the surface detail. A moderate tele setting gives cleaner background separation."},
            {"Food","Dessert Closeup","Creamy highlights • detail","Tap-focus on the leading edge of the dessert and protect bright cream highlights."},
            {"Food","Street Food","Documentary color • heat and texture","Use a fast shutter if the cook is moving and stay close to the action."},
            {"Food","Flatlay Brunch","Top-down arrangement • balanced light","Keep the camera parallel to the table. Use soft window light from one side."},
            {"Product","Clean Product","Neutral background • crisp edges","Use soft daylight, a low ISO, and a stable phone. Keep the product square to the camera."},
            {"Product","Dark Product","Black background • controlled highlight","Light the product from one side and expose for the brightest edge."},
            {"Product","Luxury Product","Specular highlight • premium mood","Use one large soft source plus a dark side to create controlled reflections."},
            {"Product","Flatlay Product","Graphic top-down product frame","Lock the phone parallel to the surface. Keep the layout clean and repeatable."},
            {"Product","Color Block Product","Bold color • graphic shadow","Use a simple colored surface and directional light for one clean shadow."},
            {"Product","Texture Product","Material detail • shallow-looking depth","Use the tele/macro option if available and move the light across the surface."},
            {"Action","Freeze Jump","Crisp movement • clean background","Use a fast shutter and raise ISO only as needed. Pre-focus or continuous AF."},
            {"Action","Running Subject","Frozen stride • environmental scene","Track the subject and keep at least 1/500s in daylight."},
            {"Action","Sports Burst","Peak action • sharp detail","Choose the longest useful lens with sufficient light and use the fastest safe shutter."},
            {"Action","Cyclist Motion","Fast subject • street context","Stand where the cyclist crosses your frame and pan or freeze intentionally."},
            {"Action","Splash Freeze","Water droplets • crisp timing","Use a fast shutter and strong daylight. Shoot a burst if Pro mode allows it."},
            {"Action","Dance Motion","Pose at peak • gesture","Watch rehearsal, choose the moment, and keep shutter high enough to stop hands."},
            {"Nature","Leaf Detail","Texture • quiet greens • detail","Use side light and get close. Avoid direct overhead sun if possible."},
            {"Nature","Flower Macro","Fine detail • soft background","Use a tele/macro-capable lens and lock focus on the closest important petal."},
            {"Nature","Forest Path","Depth • layered greens","Look for a path or line leading into the scene. Keep the phone level."},
            {"Nature","Mountain Layers","Compressed landscape • haze","Use telephoto to stack layers and emphasize atmospheric depth."},
            {"Nature","Golden Grass","Warm backlight • soft texture","Backlight the grass near sunset and protect the sky highlights."},
            {"Nature","Cloudscape","Big sky • graphic cloud form","Use the main lens and expose for bright clouds rather than dark land."},
            {"Minimal","Single Subject","Negative space • clean form","Leave breathing room around the subject and simplify the background."},
            {"Minimal","Negative Space","Small subject • large field","Under-compose the subject and let the empty area become part of the design."},
            {"Minimal","Monochrome Form","One-tone object • soft shadow","Find a scene dominated by one color and remove unnecessary visual noise."},
            {"Minimal","Pastel Wall","Soft color • tiny subject","Use open shade and keep saturation restrained. Let the wall do most of the work."},
            {"Minimal","Shadow Pattern","Graphic shadow • hard edge","Shoot when the sun creates strong repeating shadows across a simple surface."},
            {"Minimal","Quiet Morning","Soft light • calm atmosphere","Use early daylight, low contrast, and simple framing."},
            {"Vintage","Retro Street","Analog mood • warm highlights","Use warm WB, modest contrast, and slightly underexpose to keep highlights controlled."},
            {"Vintage","Analog Portrait","Flash-like snapshot • direct gaze","Use a faster shutter, neutral-to-warm WB, and a simple background."},
            {"Vintage","Faded Summer","Soft color • sun haze","Shoot through gentle backlight and keep the scene slightly brighter."},
            {"Vintage","Flash Snapshot","Direct flash feel • crisp subject","If using flash, keep the background visible and avoid reflective surfaces behind the subject."},
            {"Vintage","Old Camera Look","Centered composition • imperfect feel","Keep framing simple and let natural texture remain rather than over-sharpening."},
            {"Vintage","Sepia Interior","Warm room • quiet detail","Use window light and warm WB. Avoid mixed fluorescent light if possible."},
            {"Silhouette","Sunset Silhouette","Graphic outline • orange sky","Tap the bright sky, lower exposure, and keep the subject shape separated from the horizon."},
            {"Silhouette","Window Silhouette","Interior subject • bright exterior","Expose for the exterior and keep the subject close to the window."},
            {"Silhouette","Palm Silhouette","Tropical outline • bold sky","Use a low angle and place the palm against the brightest area of sky."},
            {"Silhouette","Rooftop Silhouette","Person against skyline","Shoot from a lower angle so the skyline stays visible behind the outline."},
            {"Silhouette","Profile Silhouette","Face profile • clean contour","Ask the subject to turn sideways and keep hair/background separation clean."},
            {"Silhouette","Minimal Silhouette","One shape • large field","Use a simple sky or wall and expose for the brightest tone."},
            {"Astro","Starscape","Stars • landscape foreground","Use a solid support, very long shutter, low ISO, manual focus near infinity, and avoid unnecessary light."},
            {"Astro","Moon Detail","Crisp moon • dark sky","Use the telephoto and a fast shutter because the moon is much brighter than the sky."},
            {"Astro","City Stars","Stars above skyline • ambient glow","Find a darker viewpoint away from direct lamps and keep the skyline as a small anchor."},
            {"Astro","Milky Way Mood","Dark sky • subtle foreground","Use the main lens, solid support, manual focus, and the slowest practical shutter without star trailing."},
            {"Astro","Night Sky","Simple starscape • deep blacks","Keep the frame dark and avoid bright signs entering the corners."},
            {"Astro","Moonlit Landscape","Cool light • quiet terrain","Use a stable surface and expose for the terrain while preserving moon highlights."},
            {"Motion Blur","Walking Blur","Intentional movement • static scene","Lower shutter into the 1/8–1/2s range and keep the camera steady."},
            {"Motion Blur","Traffic Blur","Headlight streaks • static buildings","Use 1–4s on a support and keep ISO low."},
            {"Motion Blur","Spin Blur","Radial energy • moving subject","Try 1/4–1s and rotate or move in a controlled way depending on the scene."},
            {"Motion Blur","Light Sweep","Abstract line of light","Use a slow shutter and a stable starting composition."},
            {"Motion Blur","Train Blur","Speed impression • platform frame","Pan or let the train streak across a locked frame; choose one technique."},
            {"Motion Blur","Handheld Panning","Sharp subject • blurred background","Track the subject smoothly across the frame with a moderate shutter."},
            {"Luxury","Luxury Portrait","Premium lighting • polished skin","Use the tele camera when light allows, keep the background clean, and use soft side light."},
            {"Luxury","Watch Detail","Metal highlights • premium texture","Angle the light so one edge catches a clean specular highlight without clipping."},
            {"Luxury","Car Detail","Body reflections • dramatic line","Use a telephoto view and move until reflections form clean graphic shapes."},
            {"Luxury","Hotel Interior","Warm architecture • symmetry","Use a wide/main lens and keep verticals straight. Turn off mixed overhead lights when possible."},
            {"Luxury","Fashion Editorial","Strong pose • controlled background","Use 50–85mm-class framing for flattering compression when there is enough light."},
            {"Luxury","Night Glamour","Highlights • city ambience","Expose for the face and keep background practicals a stop or two down."},
            {"Black & White","High-Key B&W","Bright tones • soft contrast","Use a light background and even illumination. Let texture come from form, not color."},
            {"Black & White","Low-Key B&W","Deep blacks • strong highlights","Use one directional light and preserve a single bright focal area."},
            {"Black & White","Street B&W","Decisive moment • graphic shadow","Look for high-contrast light and wait for a clean subject gesture."},
            {"Black & White","Portrait B&W","Skin texture • timeless contrast","Use side light and a moderate tele focal length for natural proportions."},
            {"Black & White","Architecture B&W","Form • repetition • shadow","Shoot under directional light to separate planes and surfaces."},
            {"Black & White","Minimal B&W","Shape • negative space","Reduce the scene to one or two tones and keep composition very clean."}
        };
        int i=0;
        for(String[] row:data){
            int variant=i%6;
            recipes.add(makeRecipe(row[0],row[1],row[2],row[3],variant,i+1));
            i++;
        }
    }

    Recipe makeRecipe(String cat,String title,String desc,String note,int v,int idx){
        String lens="Main / 23–24mm"; int iso=100, wb=5200; double sh=1.0/250.0, ev=0.0; String focus="AF"; String aperture="Fixed";
        if(cat.equals("Portrait")){ lens=v>=2?"Tele / 50–85mm":"Main / 23–24mm"; iso=v==4?400:100; sh=1.0/(v==4?125:250); wb=v==1?5600:5000; ev=-0.3; focus="Face AF"; }
        else if(cat.equals("Golden Hour")){ lens=v==4?"Tele / 50–85mm":"Main / 23–24mm"; iso=50; sh=1.0/(v==0?250:500); wb=5800; ev=-0.7; focus="AF"; }
        else if(cat.equals("Blue Hour")){ lens=v==1?"Tele / 50–85mm":"Main / 23–24mm"; iso=v>=4?400:200; sh=v>=2?1.0/30.0:1.0/60.0; wb=4300; ev=-0.3; focus="AF"; }
        else if(cat.equals("Night")){ lens=v==2?"Tele / 50–85mm":"Main / 23–24mm"; iso=v==4?100:800; sh=v==4?2.0:1.0/100.0; wb=3900; ev=-0.7; focus=v==4?"MF / ∞":"AF"; }
        else if(cat.equals("Street")){ lens="Main / 23–24mm"; iso=100; sh=1.0/(v==5?1000:500); wb=5000; ev=-0.3; focus="Continuous AF"; }
        else if(cat.equals("Cinematic")){ lens=v==1?"Tele / 50–85mm":"Main / 23–24mm"; iso=v==4?800:200; sh=1.0/125.0; wb=v==1?4000:4800; ev=-0.7; focus="AF"; }
        else if(cat.equals("Rain")){ lens=v>=4?"Tele / 50–85mm":"Main / 23–24mm"; iso=400; sh=1.0/125.0; wb=4200; ev=-0.7; focus="AF"; }
        else if(cat.equals("Travel")){ lens=v==1||v==2?"Tele / 50–85mm":"Main / 23–24mm"; iso=100; sh=1.0/250.0; wb=5200; ev=-0.3; focus="AF"; }
        else if(cat.equals("Architecture")){ lens=v==0||v==4?"Main / 23–24mm":"Main / 23–24mm"; iso=50; sh=1.0/125.0; wb=5200; ev=0.0; focus="AF"; }
        else if(cat.equals("Food")){ lens=v>=2?"Tele / 50–85mm":"Main / 23–24mm"; iso=100; sh=1.0/100.0; wb=4300; ev=-0.3; focus="Single AF"; }
        else if(cat.equals("Product")){ lens=v==2||v==5?"Tele / 50–85mm":"Main / 23–24mm"; iso=50; sh=1.0/100.0; wb=5200; ev=0.0; focus="Single AF"; }
        else if(cat.equals("Action")){ lens=v>=2?"Tele / 50–85mm":"Main / 23–24mm"; iso=200; sh=1.0/1000.0; wb=5000; ev=-0.3; focus="Continuous AF"; }
        else if(cat.equals("Nature")){ lens=v==1||v==3?"Tele / 50–85mm":"Main / 23–24mm"; iso=100; sh=1.0/500.0; wb=5400; ev=-0.3; focus="AF"; }
        else if(cat.equals("Minimal")){ lens=v==0||v==3?"Main / 23–24mm":"Tele / 50–85mm"; iso=50; sh=1.0/250.0; wb=5400; ev=-0.3; focus="AF"; }
        else if(cat.equals("Vintage")){ lens=v==1||v==3?"Main / 23–24mm":"Tele / 50–85mm"; iso=v==3?400:100; sh=v==3?1.0/125.0:1.0/250.0; wb=6000; ev=-0.3; focus="AF"; }
        else if(cat.equals("Silhouette")){ lens=v==3?"Tele / 50–85mm":"Main / 23–24mm"; iso=50; sh=1.0/500.0; wb=5800; ev=-1.3; focus="AF / bright sky"; }
        else if(cat.equals("Astro")){ lens=v==1?"Tele / 50–85mm":"Main / 23–24mm"; iso=v==1?400:1600; sh=v==1?1.0/250.0:10.0; wb=3600; ev=-0.3; focus="Manual / ∞"; }
        else if(cat.equals("Motion Blur")){ lens="Main / 23–24mm"; iso=50; sh=v==1||v==4?3.0:0.5; wb=4300; ev=-0.3; focus="AF then lock"; }
        else if(cat.equals("Luxury")){ lens=v==0||v==4?"Tele / 50–85mm":"Main / 23–24mm"; iso=100; sh=1.0/250.0; wb=4600; ev=-0.3; focus="Face AF"; }
        else if(cat.equals("Black & White")){ lens=v==3?"Tele / 50–85mm":"Main / 23–24mm"; iso=100; sh=1.0/250.0; wb=5200; ev=-0.7; focus="AF"; }
        return new Recipe(title,desc,"ref_"+String.format(Locale.US,"%03d",idx),cat,lens,iso,wb,sh,focus,ev,note,aperture);
    }

    void setupRoot(){ root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(BG); root.setPadding(dp(16),dp(12),dp(16),dp(16)); setContentView(root); }
    void header(String title,String sub){ LinearLayout h=new LinearLayout(this); h.setOrientation(LinearLayout.VERTICAL); h.setPadding(0,0,0,dp(12)); h.addView(tv(title,28,TEXT,true)); h.addView(tv(sub,13,MUTED,false)); root.addView(h); }

    void home(){
        showingRecipe=false;
        setupRoot();
        header("ShotRecipe","Pick a built-in reference → choose your phone → get a Pro Mode starting recipe.");
        LinearLayout controls=new LinearLayout(this); controls.setOrientation(LinearLayout.VERTICAL); controls.setPadding(dp(12),dp(10),dp(12),dp(10)); controls.setBackground(bg(CARD,18));
        TextView lab=tv("MY PHONE",10,MUTED,true); controls.addView(lab,new LinearLayout.LayoutParams(-1,dp(20)));
        deviceSpinner=new Spinner(this); ArrayAdapter<String> ad=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,deviceNames()); deviceSpinner.setAdapter(ad); controls.addView(deviceSpinner,new LinearLayout.LayoutParams(-1,dp(46)));
        root.addView(controls,new LinearLayout.LayoutParams(-1,dp(88)));

        LinearLayout searchRow=new LinearLayout(this); searchRow.setPadding(0,dp(12),0,dp(8));
        searchBox=new EditText(this); searchBox.setSingleLine(true); searchBox.setHint("Search 120 photo references…"); searchBox.setHintTextColor(Color.rgb(120,128,140)); searchBox.setTextColor(TEXT); searchBox.setTextSize(14); searchBox.setPadding(dp(14),0,dp(14),0); searchBox.setBackground(bg(Color.rgb(27,32,41),18));
        searchRow.addView(searchBox,new LinearLayout.LayoutParams(0,dp(48),1));
        Button fav=button("☆ Favorites"); searchRow.addView(fav,new LinearLayout.LayoutParams(dp(112),dp(48)));
        root.addView(searchRow);
        fav.setOnClickListener(v->{ favoritesOnly=!favoritesOnly; fav.setText(favoritesOnly?"★ Favorites":"☆ Favorites"); renderLibrary(); });
        searchBox.addTextChangedListener(new TextWatcher(){ public void beforeTextChanged(CharSequence s,int a,int c,int d){} public void onTextChanged(CharSequence s,int a,int b,int c){renderLibrary();} public void afterTextChanged(Editable e){} });
        deviceSpinner.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onNothingSelected(android.widget.AdapterView<?> p){} public void onItemSelected(android.widget.AdapterView<?> p,View v,int pos,long id){}});

        HorizontalScrollView hs=new HorizontalScrollView(this); hs.setHorizontalScrollBarEnabled(false); LinearLayout chips=new LinearLayout(this); chips.setPadding(0,0,0,dp(8));
        ArrayList<String> cats=new ArrayList<>(); cats.add("All"); for(Recipe r:recipes) if(!cats.contains(r.category)) cats.add(r.category);
        for(String c:cats){ Button cb=button(c); cb.setPadding(dp(14),0,dp(14),0); cb.setOnClickListener(v->{ selectedCategory=c; for(int k=0;k<chips.getChildCount();k++){ View child=chips.getChildAt(k); if(child instanceof Button){((Button)child).setAlpha(0.75f);} } cb.setAlpha(1f); renderLibrary(); }); cb.setAlpha(c.equals("All")?1f:.75f); chips.addView(cb,new LinearLayout.LayoutParams(-2,dp(42))); }
        hs.addView(chips); root.addView(hs);

        LinearLayout meta=new LinearLayout(this); meta.setGravity(Gravity.CENTER_VERTICAL); countLabel=tv("",11,MUTED,true); meta.addView(countLabel,new LinearLayout.LayoutParams(0,dp(28),1)); TextView info=tv("Original built-in visual references",10,MUTED,false); meta.addView(info); root.addView(meta);
        ScrollView s=new ScrollView(this); s.setFillViewport(true); library=new LinearLayout(this); library.setOrientation(LinearLayout.VERTICAL); s.addView(library); root.addView(s,new LinearLayout.LayoutParams(-1,0,1)); renderLibrary();
    }

    void renderLibrary(){
        if(library==null)return; library.removeAllViews(); String q=searchBox==null?"":searchBox.getText().toString().trim().toLowerCase(Locale.US); int shown=0;
        for(final Recipe r:recipes){
            boolean catOk=selectedCategory.equals("All") || r.category.equals(selectedCategory); boolean textOk=q.isEmpty() || r.name.toLowerCase(Locale.US).contains(q) || r.desc.toLowerCase(Locale.US).contains(q) || r.category.toLowerCase(Locale.US).contains(q); boolean favOk=!favoritesOnly || isFavorite(r);
            if(!(catOk&&textOk&&favOk)) continue; shown++;
            LinearLayout card=new LinearLayout(this); card.setOrientation(LinearLayout.HORIZONTAL); card.setGravity(Gravity.CENTER_VERTICAL); card.setPadding(dp(8),dp(8),dp(8),dp(8)); card.setBackground(bg(CARD,18));
            ImageView im=new ImageView(this); im.setImageResource(getResources().getIdentifier(r.image,"drawable",getPackageName())); im.setScaleType(ImageView.ScaleType.CENTER_CROP); card.addView(im,new LinearLayout.LayoutParams(dp(114),dp(84)));
            LinearLayout texts=new LinearLayout(this); texts.setOrientation(LinearLayout.VERTICAL); texts.setPadding(dp(12),0,dp(4),0); texts.addView(tv(r.name,15,TEXT,true)); texts.addView(tv(r.desc,11,MUTED,false)); TextView pill=tv(r.category+"  •  "+bestLensShort(r),10,ACCENT,true); texts.addView(pill,new LinearLayout.LayoutParams(-1,dp(24))); card.addView(texts,new LinearLayout.LayoutParams(0,-2,1));
            TextView star=tv(isFavorite(r)?"★":"☆",24,isFavorite(r)?ACCENT:MUTED,false); star.setGravity(Gravity.CENTER); card.addView(star,new LinearLayout.LayoutParams(dp(30),dp(60)));
            card.setOnClickListener(v->showRecipe(r)); star.setOnClickListener(v->{toggleFavorite(r); renderLibrary();});
            LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,dp(100)); cp.setMargins(0,0,0,dp(8)); library.addView(card,cp);
        }
        if(countLabel!=null) countLabel.setText(shown+" reference"+(shown==1?"":"s"));
        if(shown==0){ TextView empty=tv("No references match this filter.",14,MUTED,false); empty.setGravity(Gravity.CENTER); library.addView(empty,new LinearLayout.LayoutParams(-1,dp(120))); }
    }

    boolean isFavorite(Recipe r){ return prefs.getBoolean("fav_"+r.image,false); }
    void toggleFavorite(Recipe r){ prefs.edit().putBoolean("fav_"+r.image,!isFavorite(r)).apply(); }
    String[] deviceNames(){ String[] a=new String[devices.size()]; for(int i=0;i<a.length;i++)a[i]=devices.get(i).name; return a; }
    Device selected(){ int i=deviceSpinner.getSelectedItemPosition(); return devices.get(Math.max(0,Math.min(i,devices.size()-1))); }
    String bestLensShort(Recipe r){ return r.lens.replace(" / "," "); }

    void showRecipe(Recipe r){
        showingRecipe=true;
        setupRoot();
        LinearLayout top=new LinearLayout(this); top.setGravity(Gravity.CENTER_VERTICAL); TextView back=tv("‹",38,TEXT,false); top.addView(back,new LinearLayout.LayoutParams(dp(42),dp(52))); TextView title=tv(r.name,21,TEXT,true); top.addView(title,new LinearLayout.LayoutParams(0,dp(52),1)); TextView star=tv(isFavorite(r)?"★":"☆",28,isFavorite(r)?ACCENT:MUTED,false); top.addView(star,new LinearLayout.LayoutParams(dp(40),dp(52))); root.addView(top);
        back.setOnClickListener(v->home()); star.setOnClickListener(v->{toggleFavorite(r); showRecipe(r);});
        ImageView hero=new ImageView(this); hero.setImageResource(getResources().getIdentifier(r.image,"drawable",getPackageName())); hero.setScaleType(ImageView.ScaleType.CENTER_CROP); root.addView(hero,new LinearLayout.LayoutParams(-1,dp(218)));
        Device d=selected(); root.addView(tv("ADAPTED FOR "+d.name.toUpperCase(Locale.US),10,MUTED,true),new LinearLayout.LayoutParams(-1,dp(34)));
        LinearLayout grid=new LinearLayout(this); grid.setOrientation(LinearLayout.VERTICAL); grid.setBackground(bg(CARD,18));
        addPair(grid,"BEST CAMERA",adaptLens(r,d),"ISO",String.valueOf(r.iso));
        addPair(grid,"SHUTTER",formatShutter(r.shutter),"WHITE BALANCE",r.wb+" K");
        addPair(grid,"FOCUS",r.focus,"EXPOSURE",formatEv(r.ev));
        addPair(grid,"APERTURE",apertureFor(r,d),"MODE","Pro / manual exposure");
        root.addView(grid,new LinearLayout.LayoutParams(-1,dp(236)));
        TextView tip=tv("HOW TO GET THE LOOK",11,MUTED,true); root.addView(tip,new LinearLayout.LayoutParams(-1,dp(38))); TextView inst=tv(adaptNote(r,d),14,TEXT,false); inst.setBackground(bg(Color.rgb(27,34,47),18)); inst.setPadding(dp(15),dp(13),dp(15),dp(13)); root.addView(inst,new LinearLayout.LayoutParams(-1,dp(130)));
        TextView detail=tv("WHY THESE SETTINGS",11,MUTED,true); root.addView(detail,new LinearLayout.LayoutParams(-1,dp(38))); TextView why=tv(whyText(r),13,MUTED,false); why.setPadding(dp(2),0,dp(2),dp(10)); root.addView(why,new LinearLayout.LayoutParams(-1,dp(86)));
        TextView note=tv("These are starting points, not guaranteed matches. Scene brightness, subject reflectance, phone processing and available Pro controls can change the final result.",11,MUTED,false); note.setPadding(0,dp(8),0,0); root.addView(note);
    }

    String adaptLens(Recipe r,Device d){ if(r.lens.startsWith("Tele")) return d.name.equals("vivo X300 Pro")?"Tele / ~85mm class":d.name.equals("vivo X300")?"Tele / ~50mm class":"Longest optical lens"; if(r.lens.startsWith("Main")) return d.name.equals("vivo X300 Pro")?"Main / ~24mm class":d.name.equals("vivo X300")?"Main / ~23mm class":"Main / ~24mm class"; return r.lens; }
    String apertureFor(Recipe r,Device d){ if(r.lens.startsWith("Tele")) return "f/"+String.format(Locale.US,"%.2f",d.teleA); if(r.lens.startsWith("Main")) return "f/"+String.format(Locale.US,"%.2f",d.mainA); return "Use phone's fixed aperture"; }
    String adaptNote(Recipe r,Device d){ return r.note+"\n\nOn "+d.name+", start with these values and adjust shutter or ISO until the Pro-mode exposure meter is close to your target."; }
    String whyText(Recipe r){ if(r.iso<=100) return "Low ISO keeps fine detail cleaner. The shutter is chosen for a controlled hand-held exposure, while the WB is set to preserve the intended mood rather than relying on auto WB."; if(r.shutter<0.02) return "The very fast shutter prioritizes motion control. ISO is intentionally allowed to rise because a sharp noisy frame is usually more useful than a clean blurred one."; if(r.shutter>=2) return "The long shutter creates intentional light accumulation and blur. A solid support is essential, so ISO can remain low."; return "The recipe balances shutter speed, ISO and color temperature around the visual target. Use the reference image as the north star and fine-tune exposure on location."; }
    void addPair(LinearLayout parent,String a,String av,String b,String bv){ LinearLayout row=new LinearLayout(this); row.setPadding(dp(14),dp(9),dp(14),dp(9)); row.addView(pair(a,av),new LinearLayout.LayoutParams(0,-1,1)); row.addView(pair(b,bv),new LinearLayout.LayoutParams(0,-1,1)); parent.addView(row); }
    LinearLayout pair(String k,String v){ LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); l.addView(tv(k,9,MUTED,true)); l.addView(tv(v,16,TEXT,true)); return l; }
    String formatShutter(double s){ if(s>=1) return (Math.abs(s-Math.round(s))<0.01?String.format(Locale.US,"%.0f s",s):String.format(Locale.US,"%.1f s",s)); return "1/"+Math.round(1.0/s); }
    String formatEv(double e){ return (e>0?"+":"")+String.format(Locale.US,"%.1f EV",e); }

    static class Device { String name,desc; int mainF,teleF,uwF; double mainA,teleA,uwA; Device(String n,String d,int m,int t,int u,double ma,double ta,double ua){name=n;desc=d;mainF=m;teleF=t;uwF=u;mainA=ma;teleA=ta;uwA=ua;} }
    static class Recipe { String name,desc,image,category,lens,focus,note,apertureLabel; int iso,wb; double shutter,ev; Recipe(String n,String d,String i,String c,String l,int is,int w,double sh,String fo,double e,String no,String ap){name=n;desc=d;image=i;category=c;lens=l;iso=is;wb=w;shutter=sh;focus=fo;ev=e;note=no;apertureLabel=ap;} }
}
