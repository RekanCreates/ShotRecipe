# ShotRecipe v0.2 — Android

ShotRecipe is a no-account, offline-first Android app for browsing a built-in library of **120 original visual reference plates** and turning them into phone-specific Pro Mode starting recipes.

## Included in v0.2
- 120 references across 20 categories.
- Search across the library.
- Category filters.
- Favorites stored locally on the phone.
- Phone profiles for vivo X300, vivo X300 Pro, and Generic Android.
- Device-aware lens/aperture adaptation.
- Recipe detail with camera, ISO, shutter, white balance, focus, EV, and shooting guidance.
- No ads, no account, no API key, no paid SDKs, no internet required at runtime.
- GitHub Actions workflow to build the APK in the cloud.

## Important accuracy note
The recipe engine produces **starting points**, not mathematically guaranteed copies. Smartphone computational photography, lighting, distance, lens availability, firmware, and the exact Pro-mode control set all affect the final result.

### vivo profile basis
The vivo India product pages currently list:
- X300: 200MP main camera, 50MP wide-angle, 50MP 3x telephoto; rear apertures f/1.57, f/2.0, f/2.67.
- X300 Pro: 50MP main, 50MP wide-angle, 200MP 3.5x telephoto; rear apertures f/1.57, f/2.0, f/2.67; vivo also highlights an 85mm-class portrait focal length.

## Free build path
The included GitHub Actions workflow is intended to let you build the debug APK from a public GitHub repository without paying for a computer-based build environment. GitHub currently states that standard hosted runners are free and unlimited for public repositories.

## Next engineering step
A stronger v0.3 should move the recipe definitions into JSON, add many more phone profiles, add an onboarding calibration test, and eventually connect the app to CameraX/Camera2 metadata so it can read the device's actual supported ISO/shutter/WB ranges instead of assuming them.
